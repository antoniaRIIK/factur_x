======================
Factur-X demo invoices
======================

Version 11
==========
Generated on 12/06/2019 by Alexis de Lattre <alexis.delattre@akretion.com>

Changes: add EXTENDED profile

Version 10
==========
Generated on 28/11/2018 by Alexis de Lattre <alexis.delattre@akretion.com>

Changes: revert for BT-8, we're back using UNTDID 2475!

Version 9
=========
Generated on 17/11/2018 by Alexis de Lattre <alexis.delattre@akretion.com>

Changes:
- Update for Factur-X 1.0.3, including update of nomenclature for tax point date (BT-8) using UNTDID 2005.
