* ASR-OSS (http://www.asr-oss.com)
* FactorLibre (http://www.factorlibre.com)
* Tecon (http://www.tecon.es)
* Pexego (http://www.pexego.es)
* Malagatic (http://www.malagatic.es)
* Comunitea (http://www.comunitea.com)
* Pedro M. Baeza (http://www.tecnativa.com)
* Javi Melendez <javimelex@gmail.com>
* Enric Tobella <etobella@creublanca.es>
* Adrián Gómez <adrian.gomez@pesol.es>